// Dica: usa a função 'setInterval' para atualizar o cronômetro a cada segundo e clearInterval para pausar

// Recomendo depois ver o 'Arquivo Resposta' para vocês analizarem um possível bug que o usuário pode criar