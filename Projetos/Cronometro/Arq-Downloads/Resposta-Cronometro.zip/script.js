const relogio = document.querySelector('.relogio');
const iniciar = document.querySelector('.iniciar');
const pausar = document.querySelector('.pausar');
const zerar = document.querySelector('.zerar');

let horas = 0;
let min = 0;
let seg = 0;
let ms = 0;


/* Aqui vamos criar a variável 'timer' para sempre que o usuário clicar em 'Iniciar'
O nosso programa verifica se já foi iniciado o cronômetro ou não*/
let timer;

function iniciarTimer() {
    /* Se não ter essa verificação, o cronômetro irá iniciar várias vezes (se clicar várias vezes no botão 'Iniciar')
    E se rodar várias vezes os outros botoes não irão funcionar e bugaria o cronômetro*/
    if (!timer) {
        // SetInterval - é a função que executa o código repetidamente em um intervalo de tempo definido em milissegundos
        timer = setInterval(function () {
            ms++;

            if (ms >= 100) {
                ms = 0;
                seg++;
            }
            if (seg >= 60) {
                seg = 0;
                min++;
            }
            if (min >= 60) {
                min = 0;
                horas++;
            }

            relogio.style.color = 'black';

            relogio.innerHTML = (horas > 0 ? `${horas.toString().padStart(2, '0')}:` : '') + `${min.toString().padStart(2, '0')}:${seg.toString().padStart(2, '0')}<span>:${ms.toString().padStart(2, '0')}</span>`;
        }, 10); // Definindo o intervalo aqui. 10 milissegundos = 0.01 segundos
    }
}

//==== Funções do cronômetro ====//

// Aqui selecionamos o corpo todoo da página
document.addEventListener('click', function (e) {
    // Isso pega o elemento que foi clicado
    const elemento = e.target;

    // Se o elemento clicado tiver a classe 'iniciar', ele chama a função iniciarTimer
    if (elemento.classList.contains('iniciar')) {
        iniciarTimer();
    }

    // Se o elemento clicado tiver a classe 'pausar', ele chama a função clearInterval (pausa o cronômetro)
    if (elemento.classList.contains('pausar')) {
        clearInterval(timer);
        timer = null;
        relogio.style.color = 'white';
    }

    // Se o elemento clicado tiver a classe 'zerar', ele chama a função clearInterval (pausa o cronômetro) e automaticamente zera o cronômetro
    if (elemento.classList.contains('zerar')) {
        clearInterval(timer);
        horas = 0;
        min = 0;
        seg = 0;
        ms = 0;
        timer = null;
        relogio.style.color = 'black';
        relogio.innerHTML = '00:00<span>:00</span>';
    }
});