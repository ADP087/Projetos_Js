const calculadora = document.querySelector('.calculadora');
const display = document.querySelector('#display');
let erro = false;

calculadora.addEventListener('click', (e) => {
    const el = e.target;
    
    if(el.classList.contains('btn-num')){
        paraDisplay(el.textContent);
    }

    if(el.classList.contains('btn-op')){
        const operadores = ['+', '-', '*', '/', 'x', 'X', '.'];
        const ultimo = display.value.slice(-1); // Pega último caractere do display

        if (!display.value) {
            if(el.textContent === '-' || el.textContent === '+') {
                paraDisplay(el.textContent);
                return;
            }

            return;
        }

        if(operadores.includes(ultimo)) { // .includes - Verifica se a variavel 'ultimo' é um dos elementos do array 'operadores'
            return;
        }

        paraDisplay(el.textContent);
    }

    if(el.classList.contains('btn-clear')){
        limparInput();
    }

    if(el.classList.contains('btn-del')){
        delUm();
    }

    if(el.classList.contains('btn-res')){
        resConta();
    }
});

calculadora.addEventListener('keydown', (e) => {
    if (e.keyCode === 13) {
        if (!display.value) {
            return;
        }

        resConta();
    }
});

function paraDisplay(valor) {
    if(erro) {
        display.value = '';
        erro = false;
    }

    display.value += valor;
}

function limparInput() {
    display.value = '';
}

function delUm() {
    display.value = display.value.slice(0, -1); // .slice - Pegue a string do início (0) até o penúltimo (-1) caractere
}

function resConta() {
    if (!display.value) {
        return;
    }

    let conta = display.value.replace(/x/gi, '*'); // Troca todos os 'x' por '*', g no regex significa “global”, ou seja, troca todas as ocorrências de 'x'. E o i deixa todas as letras minusculas

    const ultimo = display.value.slice(-1); // Pega o último caractere do display

    if(ultimo == '*' || ultimo == '/') {
        conta += '1';
    } else if(isNaN(ultimo)) {
        conta = conta.slice(0, -1); // Remove o último caractere inválido
    }

    // Usei o Try-Catch para evitar erros de sintaxe na expressão matemática. Se a expressão for inválida, o catch irá capturar o erro e exibir uma mensagem de erro
    try {
        // eval - é uma função que avalia uma string como código JavaScript. Aqui, ela avalia a expressão matemática contida na variável 'conta'.
        // Não é recomendado usar 'eval' em código de produção devido a questões de segurança, mas é útil para este exemplo simples.
        let resultado = eval(conta); 
        display.value = resultado;
    } catch (e) { // Armazena o erro na variável 'e'
        display.value = 'Conta inválida!';
        erro = true;
    }

    display.focus();
}