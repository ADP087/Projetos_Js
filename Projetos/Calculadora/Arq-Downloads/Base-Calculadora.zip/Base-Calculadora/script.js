// Nessa base eu usei um 'input' como display para ser um pouco mais desafiante, mas se quiser mais fácil pode substituir por um 'div' ou 'span' ou 'p' e usar innerHTML para exibir os resultados.

// Dica: Usa 'eval' para calcular expressões matemáticas, mas tenha cuidado com segurança se for usar em produção.
// E use 'try...catch' para lidar com erros de sintaxe ou outros problemas na expressão.