// Aqui vai dar um pouco de trabalho
// Mas só ter pasciência, você consegue