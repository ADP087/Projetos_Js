// Aqui vai complicar um pouquinho a mais
/* Recomendo você não ter medo de criar funções, prefiro que cada função faça uma coisa só 
(pode ser complicado eu sei mas não tenham medo de errar)*/