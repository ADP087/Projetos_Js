// Dica: Guarda os botões em de mais em um array e os botões de menos em outro array
// Depois usa o 'forEach' para adicionar o evento de click em cada botão