const spans = document.querySelectorAll('.botoes span');
const mais = document.querySelectorAll('.mais');
const menos = document.querySelectorAll('.menos');
const clear = document.querySelector('.limpar');
const spanTotal = document.querySelector('.vaTotal');

let total = 0;

// Colocando uma função que cada botão do mais
mais.forEach(btn => {
    btn.addEventListener('click', () => { // Usando arrow function
        const produto = btn.closest('.produto'); // Pega o elemento mais próximo com a classe 'produto'
        const spanValor = produto.querySelector('.valor'); // Pega o span que contém o valor do produto
        const span = btn.parentElement.querySelector('span'); // Pega o span que está dentro do pai do botão clicado

        let valor = parseValor(spanValor.innerText);
        let quant = Number(span.innerText);

        quant++;
        total += valor;

        span.innerText = quant;
        spanTotal.innerText = total.toLocaleString('pt-BR', { minimumFractionDigits: 2 }); // Recebe o toal e formata para o padrão brasileiro
    });
});

// Colocando uma função que cada botão de menos
menos.forEach(btn => {
    btn.addEventListener('click', () => {
        const produto = btn.closest('.produto');
        const spanValor = produto.querySelector('.valor');
        const span = btn.parentElement.querySelector('span');

        let valor = Number(parseValor(spanValor.innerText));
        let quant = Number(span.innerText);

        quant--;
        if(quant < 0) {
            quant = 0;
            return;
        }
        
        total -= valor;

        span.innerText = quant;
        spanTotal.innerText = total.toLocaleString('pt-BR', { minimumFractionDigits: 2 });
    });
});

// Função para converter o valor do produto de string para número
function parseValor(valor) {
    return Number(valor.replace(/\./g,'').replace(',', '.')); // Remove os pontos e substitui a vírgula por ponto
}


// Botão de limpar
clear.addEventListener('click', () => {
    spans.forEach(span => {
        span.innerText = '0';
        spanTotal.innerText = '0,00';
        total = 0;
    });
});