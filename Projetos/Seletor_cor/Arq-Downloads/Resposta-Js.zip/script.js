const corpo = document.querySelector('body');
const cor = document.querySelector('#cor');

// Definindo a cor de fundo do corpo de acordo com o valor do input pré-definido no HTML
corpo.style.backgroundColor = cor.value;

cor.addEventListener('input', function mudarCor() {
    corpo.style.backgroundColor = cor.value;
})