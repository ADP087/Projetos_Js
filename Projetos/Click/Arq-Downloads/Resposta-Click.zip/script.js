const numero = document.querySelector('.numero');
const menos = document.querySelector('#menos');
const mais = document.querySelector('#mais');
const reset = document.querySelector('#reset');

let contador = 0;

numero.textContent = contador; // Inicializa o contador com 0

mais.addEventListener('click', function aumentar() {
    contador++;

    numero.textContent = contador;
});

menos.addEventListener('click', function diminuir() {
    contador--;

    numero.textContent = contador;
});

reset.addEventListener('click', function zerar() {
    contador = 0;

    numero.textContent = contador;
});